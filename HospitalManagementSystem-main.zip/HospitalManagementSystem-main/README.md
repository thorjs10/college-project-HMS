
This is a complete Healthcare Practice Management System with vb.net (ver:2023) and MySql server.
