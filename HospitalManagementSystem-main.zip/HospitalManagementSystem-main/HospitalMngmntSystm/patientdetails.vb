﻿Imports System.Data.SqlClient

Public Class patientdetails

    Dim con As New SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\HospitalManagementSystem-main\HospitalMngmntSystm\HospitalMngmntSystem(VB.net).mdf;Integrated Security=True;Connect Timeout=30")

   

    Private Sub Display()
        con.Open()
        Dim sql = "SELECT * FROM PatientTbl"
        Dim adapter As SqlDataAdapter
        adapter = New SqlDataAdapter(sql, con)
        Dim builder As SqlCommandBuilder
        builder = New SqlCommandBuilder(adapter)
        Dim ds As DataSet
        ds = New DataSet
        adapter.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        con.Close()
    End Sub
End Class